import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';
import Forecast from './pages/Forecast';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [salesData, setSalesData] = useState(null);
  const [forecast, setForecast] = useState(null);

  return (
    <div className={darkMode ? 'dark' : ''}>
      <Router>
        <div className="min-h-screen transition-colors duration-300">
          <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
          <Routes>
            <Route path="/" element={<Dashboard salesData={salesData} />} />
            <Route path="/upload" element={<Upload setSalesData={setSalesData} setForecast={setForecast} />} />
            <Route path="/forecast" element={<Forecast forecast={forecast} salesData={salesData} />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;

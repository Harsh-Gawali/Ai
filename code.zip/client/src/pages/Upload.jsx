import { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload as UploadIcon, FileText, Loader, CheckCircle, AlertCircle, Sparkles, MapPin, Calendar, Building2, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import {
  CountrySelect,
  StateSelect,
  CitySelect,
} from "react-country-state-city";
import "react-country-state-city/dist/react-country-state-city.css";
import Ribbons from '../components/Ribbons';

const Upload = ({ setSalesData, setForecast }) => {
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [countryId, setCountryId] = useState(0);
  const [stateId, setStateId] = useState(0);
  const [cityId, setCityId] = useState(0);
  const [countryName, setCountryName] = useState('');
  const [stateName, setStateName] = useState('');
  const [cityName, setCityName] = useState('');
  const [category, setCategory] = useState('Grocery');
  const [nearbyHotspot, setNearbyHotspot] = useState('');
  const navigate = useNavigate();

  // Validate CSV file structure
  const validateCSV = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const text = e.target.result;
          const lines = text.split('\n').filter(line => line.trim());
          
          if (lines.length < 2) {
            reject('CSV file is empty or has insufficient data');
            return;
          }
          
          // Check header row
          const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
          
          // Required columns (flexible naming)
          const hasDateColumn = headers.some(h => 
            h.includes('date') || h.includes('month') || h.includes('period')
          );
          const hasProductColumn = headers.some(h => 
            h.includes('product') || h.includes('item') || h.includes('name')
          );
          const hasUnitsColumn = headers.some(h => 
            h.includes('units') || h.includes('quantity') || h.includes('sales') || h.includes('sold')
          );
          const hasPriceColumn = headers.some(h => 
            h.includes('price') || h.includes('cost')
          );
          
          if (!hasDateColumn) {
            reject('CSV must contain a date/month column (e.g., "date", "month", "period")');
            return;
          }
          if (!hasProductColumn) {
            reject('CSV must contain a product column (e.g., "product_name", "product", "item_name")');
            return;
          }
          if (!hasUnitsColumn) {
            reject('CSV must contain a units/quantity column (e.g., "units_sold", "quantity", "sales")');
            return;
          }
          if (!hasPriceColumn) {
            reject('CSV must contain a price column (e.g., "price", "unit_price", "cost")');
            return;
          }
          
          // Check if data rows exist
          if (lines.length < 3) {
            reject('CSV must contain at least 2 data rows');
            return;
          }
          
          resolve(true);
        } catch (error) {
          reject('Invalid CSV format. Please check your file structure.');
        }
      };
      
      reader.onerror = () => {
        reject('Failed to read file. Please try again.');
      };
      
      reader.readAsText(file);
    });
  };

  const onDrop = async (acceptedFiles) => {
    const file = acceptedFiles[0];
    if (!file) return;

    // Check file type
    if (!file.name.endsWith('.csv')) {
      toast.error('Please upload a CSV file only', {
        icon: '❌',
        duration: 4000,
      });
      return;
    }

    if (!cityName || !stateName || !countryName) {
      toast.error('Please select Country, State, and City first', {
        icon: '⚠️',
        duration: 4000,
      });
      return;
    }

    // Validate CSV structure
    try {
      await validateCSV(file);
      toast.success('CSV file validated successfully!', {
        icon: '✅',
        duration: 2000,
      });
    } catch (error) {
      toast.error(error, {
        icon: '❌',
        duration: 6000,
        style: {
          maxWidth: '500px',
        },
      });
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('location', cityName);
    formData.append('state', stateName);
    formData.append('country', countryName);
    formData.append('category', category);
    formData.append('nearbyHotspot', nearbyHotspot);

    try {
      toast.loading('Uploading and analyzing data...', { id: 'upload' });
      
      const uploadRes = await axios.post('/api/upload-sales-data', formData);
      setSalesData(uploadRes.data.data);

      toast.loading('Generating AI forecast...', { id: 'upload' });
      
      const forecastRes = await axios.post('/api/generate-forecast', {
        salesData: uploadRes.data.data
      });
      setForecast(forecastRes.data);

      toast.success('Forecast generated successfully!', { id: 'upload' });
      setSuccess(true);
      setTimeout(() => navigate('/forecast'), 1500);
    } catch (error) {
      console.error('Upload error:', error);
      const errorMsg = error.response?.data?.error || 'Upload failed. Please check your CSV file and try again.';
      toast.error(errorMsg, {
        id: 'upload',
        duration: 5000,
        icon: '❌',
      });
    } finally {
      setUploading(false);
    }
  };

  const loadSampleData = async () => {
    if (!cityName || !stateName || !countryName) {
      toast.error('Please select Country, State, and City first', {
        icon: '⚠️',
        duration: 4000,
      });
      return;
    }

    setUploading(true);
    try {
      toast.loading('Generating sample data...', { id: 'sample' });
      
      const sampleRes = await axios.post('/api/sample-data', {
        location: cityName,
        state: stateName,
        country: countryName,
        category,
        nearbyHotspot
      });
      setSalesData(sampleRes.data.data);

      toast.loading('Generating AI forecast...', { id: 'sample' });
      
      const forecastRes = await axios.post('/api/generate-forecast', {
        salesData: sampleRes.data.data
      });
      setForecast(forecastRes.data);

      toast.success('Sample forecast generated!', { id: 'sample' });
      setSuccess(true);
      setTimeout(() => navigate('/forecast'), 1500);
    } catch (error) {
      console.error('Sample data error:', error);
      const errorMsg = error.response?.data?.error || 'Failed to load sample data';
      toast.error(errorMsg, {
        id: 'sample',
        duration: 5000,
        icon: '❌',
      });
    } finally {
      setUploading(false);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'] },
    multiple: false
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 relative">
      {/* Ribbon Background */}
      <div className="fixed inset-0 pointer-events-none opacity-30 z-0">
        <Ribbons
          baseThickness={25}
          colors={["#3B82F6", "#6366F1", "#8B5CF6"]}
          speedMultiplier={0.4}
          maxAge={600}
          enableFade={true}
          enableShaderEffect={false}
        />
      </div>

      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: '#fff',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
          },
          success: {
            duration: 3000,
            style: {
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            },
            iconTheme: {
              primary: '#10b981',
              secondary: '#fff',
            },
          },
          error: {
            duration: 5000,
            style: {
              background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            },
            iconTheme: {
              primary: '#ef4444',
              secondary: '#fff',
            },
          },
        }}
      />

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-5xl mx-auto relative z-10"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
            className="inline-block mb-4"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full blur-xl opacity-50 animate-pulse"></div>
              <div className="relative bg-gradient-to-r from-blue-600 to-indigo-600 p-4 rounded-full">
                <TrendingUp className="text-white" size={40} />
              </div>
            </div>
          </motion.div>
          
          <h1 className="text-5xl sm:text-6xl font-bold mb-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Upload Sales Data
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Transform your sales data into actionable insights with AI-powered forecasting
          </p>
        </motion.div>

        {/* Business Information Card */}
        <motion.div variants={itemVariants} className="glass-card p-8 mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl"></div>
          
          <div className="relative">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg">
                <Building2 className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
                Business Information
              </h2>
            </div>
            
            {/* Location Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="space-y-2"
              >
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                  <MapPin size={16} className="text-blue-600" />
                  Country *
                </label>
                <div className="relative">
                  <CountrySelect
                    onChange={(e) => {
                      setCountryId(e.id);
                      setCountryName(e.name);
                      setStateId(0);
                      setStateName('');
                      setCityId(0);
                      setCityName('');
                    }}
                    placeHolder="Select Country"
                    containerClassName="w-full"
                    inputClassName="w-full px-4 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 outline-none transition-all"
                  />
                </div>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="space-y-2"
              >
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                  <MapPin size={16} className="text-indigo-600" />
                  State/Province *
                </label>
                <StateSelect
                  countryid={countryId}
                  onChange={(e) => {
                    setStateId(e.id);
                    setStateName(e.name);
                    setCityId(0);
                    setCityName('');
                  }}
                  placeHolder="Select State"
                  containerClassName="w-full"
                  inputClassName="w-full px-4 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/20 outline-none transition-all"
                />
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="space-y-2"
              >
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                  <MapPin size={16} className="text-purple-600" />
                  City *
                </label>
                <CitySelect
                  countryid={countryId}
                  stateid={stateId}
                  onChange={(e) => {
                    setCityId(e.id);
                    setCityName(e.name);
                  }}
                  placeHolder="Select City"
                  containerClassName="w-full"
                  inputClassName="w-full px-4 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-purple-500 focus:ring-4 focus:ring-purple-500/20 outline-none transition-all"
                />
              </motion.div>
            </div>

            {/* Additional Info Grid */}
            <div className="mb-6">
              <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl border-2 border-blue-200 dark:border-blue-800">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-blue-600 rounded-lg">
                    <Sparkles className="text-white" size={20} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-800 dark:text-white mb-1">
                      🤖 AI-Powered Context Detection
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Our AI automatically detects upcoming festivals, events, and current season based on your location and today's date. 
                      This ensures your forecast accounts for seasonal trends and cultural events without manual input!
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="space-y-2"
              >
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                  <Building2 size={16} className="text-blue-600" />
                  Business Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 outline-none transition-all"
                >
                  <option value="Grocery">🛒 Grocery Store</option>
                  <option value="Electronics">📱 Electronics Shop</option>
                  <option value="Cosmetics">💄 Cosmetics & Beauty</option>
                  <option value="Clothing">👔 Clothing & Fashion</option>
                  <option value="Pharmacy">💊 Pharmacy</option>
                  <option value="Hardware">🔧 Hardware Store</option>
                  <option value="General">🏪 General Retail</option>
                </select>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="space-y-2"
              >
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                  <MapPin size={16} className="text-purple-600" />
                  Nearby Hotspot (Optional)
                </label>
                <select
                  value={nearbyHotspot}
                  onChange={(e) => setNearbyHotspot(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-purple-500 focus:ring-4 focus:ring-purple-500/20 outline-none transition-all"
                >
                  <option value="">Select Hotspot</option>
                  <option value="University">🎓 University/College</option>
                  <option value="Corporate Office">🏢 Corporate Office/Business Park</option>
                  <option value="Shopping Mall">🛍️ Shopping Mall</option>
                  <option value="Market">🏪 Traditional Market</option>
                  <option value="Hospital">🏥 Hospital/Medical Center</option>
                  <option value="Stadium">🏟️ Stadium/Sports Complex</option>
                  <option value="Park">🌳 Park/Recreation Area</option>
                  <option value="Tourist Attraction">🗼 Tourist Attraction</option>
                  <option value="Transportation Hub">🚉 Transportation Hub</option>
                  <option value="Residential Complex">🏘️ Residential Complex</option>
                  <option value="Industrial Area">🏭 Industrial Area</option>
                  <option value="Tech Park">💻 Tech Park/IT Hub</option>
                </select>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Helps adjust demand based on nearby foot traffic
                </p>
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* Upload Zone */}
        <motion.div variants={itemVariants}>
          <motion.div
            {...getRootProps()}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`glass-card p-12 border-2 border-dashed cursor-pointer transition-all relative overflow-hidden ${
              isDragActive 
                ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-900/20 scale-105' 
                : 'border-slate-300 dark:border-slate-700 hover:border-blue-400'
            }`}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5"></div>
            
            <input {...getInputProps()} />
            <div className="text-center relative z-10">
              <AnimatePresence mode="wait">
                {uploading ? (
                  <motion.div
                    key="uploading"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                  >
                    <Loader className="mx-auto mb-4 animate-spin text-blue-600" size={56} />
                    <h3 className="text-2xl font-bold mb-2 text-slate-800 dark:text-white">
                      Processing...
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400">
                      Analyzing your sales data with AI
                    </p>
                  </motion.div>
                ) : success ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                  >
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      <CheckCircle className="mx-auto mb-4 text-green-600" size={56} />
                    </motion.div>
                    <h3 className="text-2xl font-bold mb-2 text-slate-800 dark:text-white">
                      Success!
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400">
                      Redirecting to your forecast...
                    </p>
                  </motion.div>
                ) : (
                  <motion.div
                    key="idle"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                  >
                    <motion.div
                      animate={{ y: [0, -10, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <UploadIcon className="mx-auto mb-4 text-slate-400" size={56} />
                    </motion.div>
                    <h3 className="text-2xl font-bold mb-2 text-slate-800 dark:text-white">
                      {isDragActive ? 'Drop your file here' : 'Drop your CSV file here'}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                      or click to browse your files
                    </p>
                    <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg text-sm font-medium">
                      <FileText size={16} />
                      CSV files only
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>

        {/* Sample Data Button */}
        <motion.div variants={itemVariants} className="mt-8 text-center">
          <motion.button
            onClick={loadSampleData}
            disabled={uploading}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group relative px-8 py-4 glass-card hover:shadow-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative flex items-center gap-3">
              <FileText size={20} className="text-blue-600" />
              <span className="font-semibold text-slate-800 dark:text-white">
                Load Sample Data
              </span>
              <Sparkles size={16} className="text-yellow-600 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </motion.button>
        </motion.div>

        {/* CSV Format Info */}
        <motion.div variants={itemVariants} className="mt-8 glass-card p-6">
          <h3 className="font-bold text-lg mb-4 text-slate-800 dark:text-white flex items-center gap-2">
            <AlertCircle size={20} className="text-blue-600" />
            CSV Format Requirements
          </h3>
          <div className="space-y-3 text-sm text-slate-600 dark:text-slate-400">
            <div className="flex items-start gap-2">
              <CheckCircle size={16} className="text-green-600 mt-0.5 flex-shrink-0" />
              <p><strong>Required Columns:</strong> month (MM-YYYY), product_name, category, units_sold, price, stocks_left</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle size={16} className="text-green-600 mt-0.5 flex-shrink-0" />
              <p><strong>Optional Columns:</strong> Any category-specific attributes (brand, warranty, size, etc.)</p>
            </div>
            <div className="mt-4">
              <p className="font-semibold mb-2 text-slate-700 dark:text-slate-300">Example:</p>
              <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-xl font-mono text-xs overflow-x-auto">
                <div className="text-blue-600 dark:text-blue-400">month,product_name,category,units_sold,price,stocks_left,brand</div>
                <div className="text-slate-600 dark:text-slate-400">01-2024,Shampoo,Personal Care,450,6.99,1200,BrandA</div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Upload;

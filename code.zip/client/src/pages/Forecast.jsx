import { motion } from 'framer-motion';
import { TrendingUp, AlertTriangle, Package, CheckCircle, Download } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const Forecast = ({ forecast, salesData }) => {
  if (!forecast || !salesData) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 text-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="glass-card p-12"
        >
          <AlertTriangle size={64} className="mx-auto mb-4 text-slate-400" />
          <h2 className="text-2xl font-bold mb-4 text-slate-800 dark:text-white">No Forecast Available</h2>
          <p className="text-slate-600 dark:text-slate-400">Please upload sales data first</p>
        </motion.div>
      </div>
    );
  }

  const topProducts = salesData.products.slice(0, 8);
  const categoryData = salesData.products.reduce((acc, p) => {
    const existing = acc.find(c => c.name === p.category);
    if (existing) {
      existing.value += p.total_revenue;
    } else {
      acc.push({ name: p.category, value: p.total_revenue });
    }
    return acc;
  }, []);

  const COLORS = ['#0ea5e9', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#6366f1'];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Demand Forecast Report
          </h1>
          <button className="px-6 py-3 glass-card hover:bg-slate-100 dark:hover:bg-slate-800 transition-all">
            <Download size={20} className="inline mr-2" />
            Export PDF
          </button>
        </div>

        <div className="glass-card p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white">AI Forecast Summary</h2>
            <span className="px-4 py-2 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-full text-sm font-semibold">
              {forecast.confidence}% Confidence
            </span>
          </div>
          <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
            {forecast.forecast.demandOutlook}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card p-6"
          >
            <h3 className="text-xl font-bold mb-4 flex items-center text-slate-800 dark:text-white">
              <TrendingUp className="mr-2 text-green-500" />
              Top Growing Products
            </h3>
            <div className="space-y-3">
              {forecast.forecast.topGrowingProducts.map((product, idx) => (
                <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-800 dark:text-white">{product.name}</span>
                    <span className="text-green-600 font-bold">{product.growth}</span>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{product.reason}</p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card p-6"
          >
            <h3 className="text-xl font-bold mb-4 flex items-center text-slate-800 dark:text-white">
              <AlertTriangle className="mr-2 text-red-500" />
              Stockout Risk
            </h3>
            <div className="space-y-3">
              {forecast.forecast.stockoutRisk.map((product, idx) => (
                <div key={idx} className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-800 dark:text-white">{product.name}</span>
                    <span className="text-red-600 font-bold">{product.risk} Risk</span>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                    Days until stockout: {product.daysUntilStockout}
                  </p>
                  <p className="text-sm font-semibold text-red-700 dark:text-red-400">{product.action}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="glass-card p-6">
            <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Product Revenue Ranking</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topProducts}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="total_revenue" fill="#0ea5e9" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Category Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-6 mb-8">
          <h3 className="text-xl font-bold mb-4 flex items-center text-slate-800 dark:text-white">
            <Package className="mr-2 text-blue-500" />
            Inventory Recommendations
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {forecast.forecast.inventoryRecommendations.map((rec, idx) => (
              <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-slate-800 dark:text-white">{rec.product}</span>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    rec.priority === 'Critical' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' :
                    rec.priority === 'High' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400' :
                    'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                  }`}>
                    {rec.priority}
                  </span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">{rec.action}</p>
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Quantity: {rec.quantity} units</p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card p-6">
          <h3 className="text-xl font-bold mb-4 flex items-center text-slate-800 dark:text-white">
            <CheckCircle className="mr-2 text-indigo-500" />
            Key Insights
          </h3>
          <ul className="space-y-3">
            {forecast.forecast.keyInsights.map((insight, idx) => (
              <li key={idx} className="flex items-start">
                <span className="w-2 h-2 bg-indigo-500 rounded-full mt-2 mr-3"></span>
                <span className="text-slate-700 dark:text-slate-300">{insight}</span>
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </div>
  );
};

export default Forecast;

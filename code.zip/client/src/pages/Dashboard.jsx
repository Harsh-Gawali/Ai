import { motion } from 'framer-motion';
import { TrendingUp, Package, AlertTriangle, BarChart3 } from 'lucide-react';
import { Link } from 'react-router-dom';
import Ribbons from '../components/Ribbons';

const Dashboard = ({ salesData }) => {
  const stats = [
    { label: 'Total Products', value: salesData?.summary?.totalProducts || 0, icon: Package, color: 'blue' },
    { label: 'Total Revenue', value: `$${(salesData?.summary?.totalRevenue || 0).toFixed(0)}`, icon: TrendingUp, color: 'green' },
    { label: 'Avg Growth', value: `${(salesData?.summary?.avgGrowthRate || 0).toFixed(1)}%`, icon: BarChart3, color: 'purple' },
    { label: 'Total Units', value: salesData?.summary?.totalUnits || 0, icon: AlertTriangle, color: 'orange' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 relative">
      {/* Ribbon Background */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-0">
        <Ribbons
          baseThickness={30}
          colors={["#3B82F6", "#8B5CF6", "#EC4899"]}
          speedMultiplier={0.3}
          maxAge={700}
          enableFade={true}
          enableShaderEffect={false}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12 relative z-10"
      >
        <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
          AI-Powered Inventory Forecasting
        </h1>
        <p className="text-xl text-slate-600 dark:text-slate-400">
          Optimize your inventory with intelligent demand predictions
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12 relative z-10">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="glass-card p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">{stat.label}</p>
                <p className="text-3xl font-bold mt-2 text-slate-800 dark:text-white">{stat.value}</p>
              </div>
              <stat.icon className={`text-${stat.color}-500`} size={40} />
            </div>
          </motion.div>
        ))}
      </div>

      {!salesData && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="glass-card p-12 text-center relative z-10"
        >
          <Package size={64} className="mx-auto mb-4 text-slate-400" />
          <h2 className="text-2xl font-bold mb-4 text-slate-800 dark:text-white">No Data Yet</h2>
          <p className="text-slate-600 dark:text-slate-400 mb-6">
            Upload your sales data to get started with AI-powered forecasting
          </p>
          <Link
            to="/upload"
            className="inline-block px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all"
          >
            Upload Data
          </Link>
        </motion.div>
      )}
    </div>
  );
};

export default Dashboard;

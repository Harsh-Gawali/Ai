import express from 'express';
import multer from 'multer';
import { processCSV } from '../controllers/uploadController.js';

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/upload-sales-data', upload.single('file'), processCSV);

export default router;

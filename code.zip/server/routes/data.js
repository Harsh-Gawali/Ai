import express from 'express';
import { getSampleData } from '../controllers/dataController.js';

const router = express.Router();

router.post('/sample-data', getSampleData);

export default router;

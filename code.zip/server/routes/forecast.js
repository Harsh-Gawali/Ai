import express from 'express';
import { generateForecast } from '../controllers/forecastController.js';

const router = express.Router();

router.post('/generate-forecast', generateForecast);

export default router;

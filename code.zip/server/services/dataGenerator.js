export const generateSyntheticData = (category = 'Grocery') => {
  const products = getCategoryProducts(category);
  
  const data = [];
  const startYear = 2015;
  const startMonth = 1;
  const endYear = 2026;
  const endMonth = 3;
  
  // Generate months from Jan 2015 to Mar 2026
  const months = [];
  for (let year = startYear; year <= endYear; year++) {
    const lastMonth = year === endYear ? endMonth : 12;
    const firstMonth = year === startYear ? startMonth : 1;
    
    for (let month = firstMonth; month <= lastMonth; month++) {
      months.push(`${String(month).padStart(2, '0')}-${year}`);
    }
  }
  
  console.log(`📅 Generating ${months.length} months of data from ${months[0]} to ${months[months.length - 1]}`);
  
  months.forEach((month, monthIndex) => {
    products.forEach(product => {
      // Long-term growth trend (11+ years)
      const longTermTrend = 1 + (monthIndex / months.length) * 0.8;
      
      // Seasonal pattern (repeats yearly)
      const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.2;
      
      // Random variation
      const randomness = 0.85 + Math.random() * 0.3;
      
      // Economic cycles (simulate market ups and downs)
      const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.15;
      
      const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
      
      // Price inflation over time (2-3% per year)
      const yearsPassed = monthIndex / 12;
      const priceInflation = Math.pow(1.025, yearsPassed);
      const price = product.basePrice * priceInflation * (0.95 + Math.random() * 0.1);
      
      // Stock levels decrease as we approach current date (simulating higher demand)
      const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
      const stocksLeft = Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4));
      
      const record = {
        month: month,
        product_name: product.name,
        category: product.category,
        units_sold: units,
        price: Math.round(price * 100) / 100,
        stocks_left: Math.max(0, stocksLeft)
      };
      
      // Add dynamic attributes
      if (product.dynamicAttributes) {
        Object.assign(record, product.dynamicAttributes);
      }
      
      data.push(record);
    });
  });
  
  console.log(`✅ Generated ${data.length} total records`);
  return data;
};

function getCategoryProducts(category) {
  const productsByCategory = {
    'Grocery': [
      { name: 'Shampoo', category: 'Personal Care', basePrice: 6.99, baseUnits: 450, baseStock: 1200, dynamicAttributes: { brand: 'BrandA', organic: 'No' } },
      { name: 'Soap', category: 'Personal Care', basePrice: 2.50, baseUnits: 600, baseStock: 800, dynamicAttributes: { brand: 'BrandB', organic: 'Yes' } },
      { name: 'Toothpaste', category: 'Oral Care', basePrice: 4.20, baseUnits: 300, baseStock: 500, dynamicAttributes: { brand: 'BrandC', organic: 'No' } },
      { name: 'Rice', category: 'Food', basePrice: 12.99, baseUnits: 250, baseStock: 300, dynamicAttributes: { brand: 'BrandD', organic: 'Yes' } },
      { name: 'Milk', category: 'Dairy', basePrice: 3.99, baseUnits: 800, baseStock: 150, dynamicAttributes: { brand: 'BrandE', organic: 'Yes' } },
      { name: 'Chips', category: 'Snacks', basePrice: 3.49, baseUnits: 550, baseStock: 900, dynamicAttributes: { brand: 'BrandF', organic: 'No' } },
      { name: 'Soft Drinks', category: 'Beverages', basePrice: 1.99, baseUnits: 1000, baseStock: 2000, dynamicAttributes: { brand: 'BrandG', organic: 'No' } },
      { name: 'Detergent', category: 'Household', basePrice: 8.99, baseUnits: 350, baseStock: 600, dynamicAttributes: { brand: 'BrandH', organic: 'No' } }
    ],
    'Electronics': [
      { name: 'Smartphone X1', category: 'Mobile', basePrice: 599.99, baseUnits: 45, baseStock: 80, dynamicAttributes: { warranty_months: 24, screen_size: '6.5' } },
      { name: 'Laptop Pro', category: 'Computers', basePrice: 1299.99, baseUnits: 25, baseStock: 30, dynamicAttributes: { warranty_months: 36, screen_size: '15.6' } },
      { name: 'Wireless Earbuds', category: 'Audio', basePrice: 89.99, baseUnits: 120, baseStock: 200, dynamicAttributes: { warranty_months: 12, screen_size: '' } },
      { name: 'Smart TV 55', category: 'Television', basePrice: 799.99, baseUnits: 35, baseStock: 40, dynamicAttributes: { warranty_months: 24, screen_size: '55' } },
      { name: 'Tablet Air', category: 'Tablets', basePrice: 449.99, baseUnits: 50, baseStock: 60, dynamicAttributes: { warranty_months: 24, screen_size: '10.5' } },
      { name: 'Gaming Console', category: 'Gaming', basePrice: 499.99, baseUnits: 40, baseStock: 25, dynamicAttributes: { warranty_months: 12, screen_size: '' } },
      { name: 'Smartwatch Pro', category: 'Wearables', basePrice: 299.99, baseUnits: 80, baseStock: 150, dynamicAttributes: { warranty_months: 24, screen_size: '1.9' } },
      { name: 'Bluetooth Speaker', category: 'Audio', basePrice: 59.99, baseUnits: 95, baseStock: 180, dynamicAttributes: { warranty_months: 12, screen_size: '' } }
    ],
    'Cosmetics': [
      { name: 'Face Cream', category: 'Skincare', basePrice: 24.99, baseUnits: 200, baseStock: 400, dynamicAttributes: { brand: 'LuxeBeauty', spf: '30' } },
      { name: 'Lipstick', category: 'Makeup', basePrice: 12.99, baseUnits: 350, baseStock: 600, dynamicAttributes: { brand: 'GlamPro', spf: '' } },
      { name: 'Perfume', category: 'Fragrance', basePrice: 49.99, baseUnits: 80, baseStock: 150, dynamicAttributes: { brand: 'Essence', spf: '' } },
      { name: 'Hair Serum', category: 'Haircare', basePrice: 18.99, baseUnits: 150, baseStock: 300, dynamicAttributes: { brand: 'SilkHair', spf: '' } },
      { name: 'Nail Polish', category: 'Makeup', basePrice: 7.99, baseUnits: 280, baseStock: 500, dynamicAttributes: { brand: 'ColorPop', spf: '' } },
      { name: 'Sunscreen', category: 'Skincare', basePrice: 15.99, baseUnits: 220, baseStock: 350, dynamicAttributes: { brand: 'SunGuard', spf: '50' } }
    ]
  };
  
  return productsByCategory[category] || productsByCategory['Grocery'];
}

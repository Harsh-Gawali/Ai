export const analyzeSalesData = (rawData, metadata = {}, columns = []) => {
  const productMap = {};
  
  // Identify standard and dynamic columns
  const standardColumns = ['date', 'month', 'product_name', 'product', 'category', 'units_sold', 'units', 'price', 'stocks_left', 'stock', 'inventory'];
  const dynamicColumns = columns.filter(col => !standardColumns.some(std => col.toLowerCase().includes(std.toLowerCase())));
  
  console.log(`🔍 Dynamic columns detected: ${dynamicColumns.join(', ') || 'None'}`);
  
  rawData.forEach(row => {
    // Flexible column mapping
    const product = row.product_name || row.product || row.item_name || row.name || 'Unknown';
    const units = parseInt(row.units_sold || row.units || row.quantity || row.sales || 0);
    const price = parseFloat(row.price || row.unit_price || row.cost || 0);
    const date = row.date || row.month || row.period || 'Unknown';
    const category = row.category || row.type || row.subcategory || metadata.category || 'General';
    const stocksLeft = parseInt(row.stocks_left || row.stock || row.inventory || row.current_stock || 0);
    
    // Collect dynamic attributes
    const dynamicAttributes = {};
    dynamicColumns.forEach(col => {
      dynamicAttributes[col] = row[col];
    });
    
    if (!productMap[product]) {
      productMap[product] = {
        name: product,
        category,
        totalSales: 0,
        totalUnits: 0,
        totalRevenue: 0,
        monthlySales: [],
        prices: [],
        stocksLeft: stocksLeft,
        dynamicAttributes: dynamicAttributes
      };
    }
    
    productMap[product].totalUnits += units;
    productMap[product].totalRevenue += units * price;
    productMap[product].monthlySales.push({ date, units });
    productMap[product].prices.push(price);
    if (stocksLeft > 0) {
      productMap[product].stocksLeft = stocksLeft;
    }
  });
  
  const products = Object.values(productMap).map(p => {
    const avgMonthlySales = p.totalUnits / (p.monthlySales.length || 1);
    const sortedSales = p.monthlySales.map(d => d.units).sort((a, b) => a - b);
    const volatility = calculateVolatility(sortedSales);
    const growthRate = calculateGrowthRate(p.monthlySales);
    const avgPrice = p.prices.reduce((a, b) => a + b, 0) / p.prices.length;
    
    // Calculate months until stockout
    const monthsUntilStockout = avgMonthlySales > 0 ? p.stocksLeft / avgMonthlySales : 999;
    
    return {
      name: p.name,
      category: p.category,
      avg_monthly_sales: Math.round(avgMonthlySales * 100) / 100,
      total_units: p.totalUnits,
      total_revenue: Math.round(p.totalRevenue * 100) / 100,
      monthly_growth_rate: Math.round(growthRate * 100) / 100,
      sales_volatility: Math.round(volatility * 100) / 100,
      avg_price: Math.round(avgPrice * 100) / 100,
      stocks_left: p.stocksLeft,
      months_until_stockout: Math.round(monthsUntilStockout * 10) / 10,
      stockout_risk: monthsUntilStockout < 2 ? 'High' : monthsUntilStockout < 4 ? 'Medium' : 'Low',
      monthlySales: p.monthlySales,
      dynamicAttributes: p.dynamicAttributes
    };
  });
  
  return {
    products: products.sort((a, b) => b.total_revenue - a.total_revenue),
    summary: {
      totalProducts: products.length,
      totalRevenue: products.reduce((sum, p) => sum + p.total_revenue, 0),
      totalUnits: products.reduce((sum, p) => sum + p.total_units, 0),
      avgGrowthRate: products.reduce((sum, p) => sum + p.monthly_growth_rate, 0) / products.length,
      totalStocksLeft: products.reduce((sum, p) => sum + p.stocks_left, 0),
      highRiskProducts: products.filter(p => p.stockout_risk === 'High').length
    },
    metadata: metadata,
    columns: {
      standard: columns.filter(col => standardColumns.some(std => col.toLowerCase().includes(std.toLowerCase()))),
      dynamic: dynamicColumns
    }
  };
};

const calculateVolatility = (sales) => {
  if (sales.length < 2) return 0;
  const mean = sales.reduce((a, b) => a + b, 0) / sales.length;
  const variance = sales.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / sales.length;
  return Math.sqrt(variance) / (mean || 1);
};

const calculateGrowthRate = (dailySales) => {
  if (dailySales.length < 7) return 0;
  const recent = dailySales.slice(-7).reduce((sum, d) => sum + d.units, 0);
  const previous = dailySales.slice(-14, -7).reduce((sum, d) => sum + d.units, 0);
  return previous > 0 ? ((recent - previous) / previous) * 100 : 0;
};

import axios from 'axios';
import https from 'https';
import dotenv from 'dotenv';

dotenv.config();

export const callLLM = async (prompt) => {
  const apiKey = process.env.LLM_API_KEY;
  const baseUrl = process.env.LLM_BASE_URL || 'https://genailab.tcs.in';
  const model = process.env.LLM_MODEL || 'azure_ai/genailab-maas-DeepSeek-V3-0324';
  
  if (!apiKey) {
    console.error('❌ No LLM API key configured');
    throw new Error('LLM API key is not configured. Please set LLM_API_KEY in .env file');
  }
  
  try {
    console.log('🔑 Using TCS GenAI Lab API');
    console.log(`📡 Base URL: ${baseUrl}`);
    console.log(`🤖 Model: ${model}`);
    
    const httpsAgent = new https.Agent({
      rejectUnauthorized: false
    });
    
    const response = await axios.post(
      `${baseUrl}/v1/chat/completions`,
      {
        model: model,
        messages: [
          {
            role: 'system',
            content: 'You are a retail demand forecasting assistant. Provide structured JSON responses for inventory analysis.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 2000
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        httpsAgent: httpsAgent,
        timeout: 30000
      }
    );
    
    console.log('✅ LLM response received');
    
    const content = response.data.choices[0].message.content;
    
    try {
      // Extract JSON if wrapped in markdown code blocks
      const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || content.match(/```\n([\s\S]*?)\n```/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[1]);
      }
      // Try direct JSON parse
      return JSON.parse(content);
    } catch (parseError) {
      console.error('❌ Could not parse LLM response as JSON');
      console.error('Response:', content.substring(0, 200));
      throw new Error('Failed to parse LLM response as JSON. Response: ' + content.substring(0, 100));
    }
    
  } catch (error) {
    console.error('❌ LLM API Error:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', JSON.stringify(error.response.data));
      throw new Error(`LLM API request failed: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
    }
    throw error;
  }
};



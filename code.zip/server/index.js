import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import uploadRoutes from './routes/upload.js';
import forecastRoutes from './routes/forecast.js';
import dataRoutes from './routes/data.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Logging middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api', uploadRoutes);
app.use('/api', forecastRoutes);
app.use('/api', dataRoutes);

app.get('/health', (req, res) => {
  console.log('✅ Health check requested');
  res.json({ status: 'ok', message: 'Server is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Error:', err.message);
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});

app.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log(`🚀 Backend Server Started`);
  console.log(`📡 Port: ${PORT}`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log(`💚 Health: http://localhost:${PORT}/health`);
  console.log(`🔑 LLM API Key: ${process.env.LLM_API_KEY ? '✓ Configured' : '✗ Not set (using mock data)'}`);
  console.log(`🤖 LLM Model: ${process.env.LLM_MODEL || 'azure_ai/genailab-maas-DeepSeek-V3-0324'}`);
  console.log(`📡 LLM Base URL: ${process.env.LLM_BASE_URL || 'https://genailab.tcs.in'}`);
  console.log('='.repeat(50));
});

import { callLLM } from '../services/llmService.js';
import { buildForecastPrompt } from '../utils/promptBuilder.js';

export const generateForecast = async (req, res) => {
  try {
    const { salesData } = req.body;
    
    if (!salesData) {
      return res.status(400).json({ error: 'Sales data is required' });
    }

    const prompt = buildForecastPrompt(salesData);
    const forecast = await callLLM(prompt);
    
    res.json({ 
      success: true, 
      forecast,
      confidence: calculateConfidence(salesData)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

function calculateConfidence(data) {
  const variance = data.products?.reduce((acc, p) => acc + (p.volatility || 0), 0) / (data.products?.length || 1);
  return Math.max(60, Math.min(95, 90 - variance * 10));
}

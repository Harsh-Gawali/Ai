import fs from 'fs';
import csv from 'csv-parser';
import { analyzeSalesData } from '../services/dataAnalyzer.js';
import { getDateContext } from '../utils/dateContextHelper.js';

export const processCSV = async (req, res) => {
  try {
    console.log('📤 CSV upload started');
    
    if (!req.file) {
      console.log('❌ No file uploaded');
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // Auto-detect season and festivals based on current date and location
    const dateContext = getDateContext(req.body.country || '', req.body.state || '');
    
    // Extract metadata from request body
    const metadata = {
      location: req.body.location || 'Unknown',
      state: req.body.state || 'Unknown',
      country: req.body.country || 'Unknown',
      category: req.body.category || 'General',
      upcomingFestival: dateContext.upcomingFestivalsString || '',
      season: dateContext.season || '',
      nearbyHotspot: req.body.nearbyHotspot || '',
      uploadDate: new Date().toISOString(),
      autoDetectedContext: {
        season: dateContext.season,
        festivals: dateContext.upcomingFestivals,
        detectedAt: dateContext.currentDate
      }
    };

    console.log(`📄 File received: ${req.file.originalname} (${req.file.size} bytes)`);
    console.log(`📍 Location: ${metadata.location}, ${metadata.state}, ${metadata.country}`);
    console.log(`🏷️  Category: ${metadata.category}`);
    console.log(`🎉 Auto-detected Festivals: ${metadata.upcomingFestival || 'None in next 60 days'}`);
    console.log(`🌤️  Auto-detected Season: ${metadata.season}`);
    console.log(`📍 Nearby Hotspot: ${metadata.nearbyHotspot || 'None'}`);
    
    const results = [];
    
    fs.createReadStream(req.file.path)
      .pipe(csv())
      .on('data', (data) => results.push(data))
      .on('end', () => {
        fs.unlinkSync(req.file.path);
        console.log(`✅ Parsed ${results.length} records`);
        
        // Extract column names from first row
        const columns = results.length > 0 ? Object.keys(results[0]) : [];
        console.log(`📋 Detected columns: ${columns.join(', ')}`);
        
        const analysis = analyzeSalesData(results, metadata, columns);
        console.log(`📊 Analysis complete: ${analysis.products.length} products`);
        
        res.json({ 
          success: true, 
          data: analysis,
          recordCount: results.length,
          metadata: metadata,
          columns: columns
        });
      })
      .on('error', (error) => {
        console.error('❌ CSV parsing error:', error.message);
        res.status(500).json({ error: 'Failed to parse CSV' });
      });
  } catch (error) {
    console.error('❌ Upload error:', error.message);
    res.status(500).json({ error: error.message });
  }
};

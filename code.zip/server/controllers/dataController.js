import { generateSyntheticData } from '../services/dataGenerator.js';
import { analyzeSalesData } from '../services/dataAnalyzer.js';
import { getDateContext } from '../utils/dateContextHelper.js';

export const getSampleData = (req, res) => {
  try {
    console.log('🎲 Generating sample data...');
    
    // Auto-detect season and festivals based on current date and location
    const dateContext = getDateContext(req.body.country || '', req.body.state || '');
    
    const metadata = {
      location: req.body.location || 'Sample City',
      state: req.body.state || 'Sample State',
      country: req.body.country || 'Sample Country',
      category: req.body.category || 'Grocery',
      upcomingFestival: dateContext.upcomingFestivalsString || '',
      season: dateContext.season || '',
      nearbyHotspot: req.body.nearbyHotspot || '',
      uploadDate: new Date().toISOString(),
      autoDetectedContext: {
        season: dateContext.season,
        festivals: dateContext.upcomingFestivals,
        detectedAt: dateContext.currentDate
      }
    };
    
    console.log(`📍 Location: ${metadata.location}, ${metadata.state}, ${metadata.country}`);
    console.log(`🏷️  Category: ${metadata.category}`);
    console.log(`🎉 Auto-detected Festivals: ${metadata.upcomingFestival || 'None in next 60 days'}`);
    console.log(`🌤️  Auto-detected Season: ${metadata.season}`);
    console.log(`📍 Nearby Hotspot: ${metadata.nearbyHotspot || 'None'}`);
    
    const rawData = generateSyntheticData(metadata.category);
    console.log(`✅ Generated ${rawData.length} sample records`);
    
    const columns = rawData.length > 0 ? Object.keys(rawData[0]) : [];
    const analysis = analyzeSalesData(rawData, metadata, columns);
    console.log(`📊 Analysis complete: ${analysis.products.length} products`);
    
    res.json({ 
      success: true, 
      data: analysis,
      rawData: rawData.slice(0, 100)
    });
  } catch (error) {
    console.error('❌ Sample data error:', error.message);
    res.status(500).json({ error: error.message });
  }
};

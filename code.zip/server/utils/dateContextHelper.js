// Helper functions to automatically determine festivals and seasons based on current date

/**
 * Get the current season based on month and hemisphere
 * @param {Date} date - Current date
 * @param {string} country - Country name to determine hemisphere
 * @returns {string} - Season name
 */
export const getCurrentSeason = (date = new Date(), country = '') => {
  const month = date.getMonth(); // 0-11
  
  // Determine hemisphere (simplified - you can expand this)
  const southernHemisphere = [
    'Australia', 'New Zealand', 'South Africa', 'Argentina', 
    'Brazil', 'Chile', 'Uruguay', 'Paraguay'
  ];
  
  const isSouthern = southernHemisphere.some(c => 
    country.toLowerCase().includes(c.toLowerCase())
  );
  
  // Northern Hemisphere seasons
  if (!isSouthern) {
    if (month >= 2 && month <= 4) return 'Spring';      // Mar-May
    if (month >= 5 && month <= 7) return 'Summer';      // Jun-Aug
    if (month >= 8 && month <= 10) return 'Autumn';     // Sep-Nov
    return 'Winter';                                     // Dec-Feb
  }
  
  // Southern Hemisphere seasons (opposite)
  if (month >= 2 && month <= 4) return 'Autumn';
  if (month >= 5 && month <= 7) return 'Winter';
  if (month >= 8 && month <= 10) return 'Spring';
  return 'Summer';
};

/**
 * Get upcoming festivals/events based on current date and location
 * @param {Date} date - Current date
 * @param {string} country - Country name
 * @param {string} state - State/province name
 * @returns {Array} - Array of upcoming festivals within next 60 days
 */
export const getUpcomingFestivals = (date = new Date(), country = '', state = '') => {
  const month = date.getMonth(); // 0-11
  const day = date.getDate();
  const year = date.getFullYear();
  
  const upcomingFestivals = [];
  
  // Helper to check if a date is within next 60 days
  const isUpcoming = (festivalMonth, festivalDay) => {
    const festivalDate = new Date(year, festivalMonth, festivalDay);
    const diffTime = festivalDate - date;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Check current year and next year
    if (diffDays >= 0 && diffDays <= 60) return true;
    
    // Check if festival is in next year but within 60 days
    const nextYearFestival = new Date(year + 1, festivalMonth, festivalDay);
    const nextYearDiff = Math.ceil((nextYearFestival - date) / (1000 * 60 * 60 * 24));
    return nextYearDiff >= 0 && nextYearDiff <= 60;
  };
  
  // Global/Western festivals
  if (isUpcoming(0, 1)) upcomingFestivals.push('New Year');
  if (isUpcoming(1, 14)) upcomingFestivals.push('Valentine\'s Day');
  if (isUpcoming(2, 17)) upcomingFestivals.push('St. Patrick\'s Day');
  if (isUpcoming(3, 1)) upcomingFestivals.push('April Fool\'s Day');
  if (isUpcoming(9, 31)) upcomingFestivals.push('Halloween');
  if (isUpcoming(10, 24)) upcomingFestivals.push('Black Friday'); // Approximate
  if (isUpcoming(10, 27)) upcomingFestivals.push('Cyber Monday'); // Approximate
  if (isUpcoming(11, 25)) upcomingFestivals.push('Christmas');
  if (isUpcoming(11, 31)) upcomingFestivals.push('New Year\'s Eve');
  
  // Easter (approximate - 3rd or 4th Sunday of March/April)
  if (month === 2 || month === 3) {
    if (isUpcoming(3, 9) || isUpcoming(3, 16)) upcomingFestivals.push('Easter');
  }
  
  // Mother's Day (2nd Sunday of May)
  if (isUpcoming(4, 14)) upcomingFestivals.push('Mother\'s Day');
  
  // Father's Day (3rd Sunday of June)
  if (isUpcoming(5, 18)) upcomingFestivals.push('Father\'s Day');
  
  // Country-specific festivals
  const countryLower = country.toLowerCase();
  
  // India
  if (countryLower.includes('india')) {
    if (isUpcoming(0, 26)) upcomingFestivals.push('Republic Day');
    if (isUpcoming(7, 15)) upcomingFestivals.push('Independence Day');
    if (isUpcoming(9, 2)) upcomingFestivals.push('Gandhi Jayanti');
    
    // Diwali (October/November - approximate)
    if (month === 9 || month === 10) {
      if (isUpcoming(10, 1) || isUpcoming(10, 12)) upcomingFestivals.push('Diwali');
    }
    
    // Holi (March - approximate)
    if (isUpcoming(2, 8) || isUpcoming(2, 25)) upcomingFestivals.push('Holi');
    
    // Raksha Bandhan (August - approximate)
    if (isUpcoming(7, 15) || isUpcoming(7, 30)) upcomingFestivals.push('Raksha Bandhan');
    
    // Navratri/Durga Puja (September/October)
    if (month === 8 || month === 9) {
      if (isUpcoming(9, 3) || isUpcoming(9, 15)) upcomingFestivals.push('Navratri/Durga Puja');
    }
  }
  
  // USA
  if (countryLower.includes('united states') || countryLower.includes('usa')) {
    if (isUpcoming(6, 4)) upcomingFestivals.push('Independence Day (4th of July)');
    if (isUpcoming(10, 23)) upcomingFestivals.push('Thanksgiving'); // 4th Thursday (approximate)
    if (isUpcoming(1, 14)) upcomingFestivals.push('Super Bowl Sunday'); // Approximate
  }
  
  // China
  if (countryLower.includes('china')) {
    // Chinese New Year (January/February - approximate)
    if (month === 0 || month === 1) {
      if (isUpcoming(1, 10) || isUpcoming(1, 1)) upcomingFestivals.push('Chinese New Year');
    }
    if (isUpcoming(9, 1)) upcomingFestivals.push('National Day');
    if (isUpcoming(8, 15)) upcomingFestivals.push('Mid-Autumn Festival'); // Approximate
  }
  
  // UK
  if (countryLower.includes('united kingdom') || countryLower.includes('uk') || countryLower.includes('england')) {
    if (isUpcoming(11, 26)) upcomingFestivals.push('Boxing Day');
  }
  
  // Canada
  if (countryLower.includes('canada')) {
    if (isUpcoming(6, 1)) upcomingFestivals.push('Canada Day');
    if (isUpcoming(10, 11)) upcomingFestivals.push('Remembrance Day');
  }
  
  // Australia
  if (countryLower.includes('australia')) {
    if (isUpcoming(0, 26)) upcomingFestivals.push('Australia Day');
  }
  
  // Islamic festivals (approximate - these follow lunar calendar)
  // Ramadan (varies - typically March/April)
  if (month === 2 || month === 3) {
    if (isUpcoming(3, 1) || isUpcoming(3, 15)) upcomingFestivals.push('Ramadan');
  }
  
  // Eid al-Fitr (after Ramadan)
  if (month === 3 || month === 4) {
    if (isUpcoming(4, 1) || isUpcoming(4, 15)) upcomingFestivals.push('Eid al-Fitr');
  }
  
  // Eid al-Adha (varies - typically June/July)
  if (month === 5 || month === 6) {
    if (isUpcoming(6, 15) || isUpcoming(6, 28)) upcomingFestivals.push('Eid al-Adha');
  }
  
  // Back to School season (August/September)
  if (month === 7 || month === 8) {
    upcomingFestivals.push('Back to School Season');
  }
  
  // Holiday Shopping Season (November/December)
  if (month === 10 || month === 11) {
    upcomingFestivals.push('Holiday Shopping Season');
  }
  
  return upcomingFestivals;
};

/**
 * Get a formatted string of upcoming festivals
 * @param {Date} date - Current date
 * @param {string} country - Country name
 * @param {string} state - State/province name
 * @returns {string} - Comma-separated list of festivals or empty string
 */
export const getUpcomingFestivalsString = (date = new Date(), country = '', state = '') => {
  const festivals = getUpcomingFestivals(date, country, state);
  return festivals.length > 0 ? festivals.join(', ') : '';
};

/**
 * Get comprehensive date context for forecasting
 * @param {string} country - Country name
 * @param {string} state - State/province name
 * @returns {Object} - Object with season and festivals
 */
export const getDateContext = (country = '', state = '') => {
  const now = new Date();
  const season = getCurrentSeason(now, country);
  const festivals = getUpcomingFestivals(now, country, state);
  
  return {
    currentDate: now.toISOString(),
    season,
    upcomingFestivals: festivals,
    upcomingFestivalsString: festivals.length > 0 ? festivals.join(', ') : null
  };
};

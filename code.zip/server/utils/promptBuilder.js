export const buildForecastPrompt = (salesData) => {
  const metadata = salesData.metadata || {
    location: 'Unknown Location',
    state: 'Unknown State',
    country: 'Unknown Country',
    category: 'General'
  };
  
  const columns = salesData.columns || { standard: [], dynamic: [] };
  
  console.log(`📍 Building prompt for: ${metadata.location}, ${metadata.state}, ${metadata.country}`);
  console.log(`🏷️  Category: ${metadata.category}`);
  
  // Extract years from the data to provide population context
  const dataYears = extractYearsFromData(salesData);
  
  // Build detailed product table with all available data
  const productsTable = salesData.products
    .slice(0, 15)
    .map(p => {
      let row = `${p.name} | ${p.category} | ${p.avg_monthly_sales} units/month | ${p.monthly_growth_rate}% growth | ${p.stocks_left} in stock | ${p.months_until_stockout} months until stockout | ${p.stockout_risk} risk`;
      
      // Add dynamic attributes if present
      if (p.dynamicAttributes && Object.keys(p.dynamicAttributes).length > 0) {
        const dynamicInfo = Object.entries(p.dynamicAttributes)
          .map(([key, value]) => `${key}: ${value}`)
          .join(', ');
        row += ` | ${dynamicInfo}`;
      }
      
      return row;
    })
    .join('\n');
  
  // Build dynamic columns description
  const dynamicColumnsDesc = columns.dynamic && columns.dynamic.length > 0
    ? `\n\nDynamic Product Attributes (specific to ${metadata.category}):\n${columns.dynamic.map(col => `- ${col}`).join('\n')}`
    : '';
  
  // Build population context based on extracted years
  const populationContext = dataYears.length > 0
    ? `\n\n👥 POPULATION-BASED DEMAND ADJUSTMENT:

Data Period: ${dataYears.join(', ')}
Location: ${metadata.location}, ${metadata.state}, ${metadata.country}

⚠️ CRITICAL REQUIREMENT - POPULATION ANALYSIS:
You MUST consider population changes when forecasting demand. Follow these steps:

1. **Identify Historical Population**: Based on the data years (${dataYears.join(', ')}), determine the approximate population of ${metadata.location}, ${metadata.state} during that period.

2. **Determine Current Population**: Estimate the current population of ${metadata.location}, ${metadata.state} (as of ${new Date().getFullYear()}).

3. **Calculate Population Factor**: 
   - Population Factor = Current Population / Historical Population
   - Example: If population was 500,000 in ${dataYears[0]} and is now 550,000, factor = 1.1x

4. **Adjust Demand Forecasts**:
   - Historical sales reflect demand at historical population levels
   - Current/future demand should be adjusted by the population factor
   - Example: Product sold 100 units/month historically → Expected current demand = 100 × population_factor

5. **Apply to Recommendations**:
   - ALL inventory recommendations MUST account for population changes
   - Explicitly mention population impact in your reasoning
   - For growing populations: Recommend higher inventory levels
   - For declining populations: Warn about overstock risks

🎯 REQUIRED IN YOUR RESPONSE:
- State the estimated historical population during data period (${dataYears.join(', ')})
- State the estimated current population (${new Date().getFullYear()})
- Calculate and mention the population adjustment factor
- Apply this factor to ALL demand forecasts and inventory recommendations
- Explain how population change impacts each major recommendation

Example reasoning format:
"The population of ${metadata.location} has grown from approximately [X] in ${dataYears[0]} to [Y] in ${new Date().getFullYear()}, representing a [Z]% increase. This population growth directly impacts demand - for example, [Product] which sold 100 units/month historically should now see demand of approximately [100 × factor] units/month. Therefore, we recommend increasing inventory by [percentage] to account for this population-driven demand increase."`
    : '';

  // Build festival and season context
  const festivalContext = metadata.upcomingFestival 
    ? `\n\n⚠️ CRITICAL: Upcoming Festival/Event (Auto-Detected): ${metadata.upcomingFestival}
This festival/event was automatically detected based on the current date (${new Date().toLocaleDateString()}) and location (${metadata.country}).

This is a MAJOR factor that will significantly impact demand. Consider:
- Increased consumer spending during ${metadata.upcomingFestival}
- Category-specific demand spikes (e.g., sweets during Diwali, electronics during Black Friday)
- Pre-festival stocking requirements
- Post-festival demand patterns
- Gift-buying behavior and promotional opportunities

🎯 FESTIVAL-SPECIFIC PRODUCT ANALYSIS REQUIRED:
You MUST identify and highlight products that are traditionally in HIGH DEMAND during ${metadata.upcomingFestival}:
- For each product, assess if it's typically purchased during ${metadata.upcomingFestival}
- Products with festival relevance should be PRIORITIZED in inventory recommendations
- Explicitly mention festival-related products in "topGrowingProducts" section
- Add specific festival-driven inventory increase recommendations
- Consider cultural and regional shopping patterns for ${metadata.upcomingFestival} in ${metadata.country}

Examples of festival-product associations:
- Diwali/Deepavali: Sweets, decorative items, new clothes, electronics, gold, crackers, gifts
- Christmas: Gifts, decorations, food items, toys, electronics, clothing, party supplies
- Black Friday: Electronics, appliances, fashion, home goods (massive discounts drive demand)
- Eid: Clothing, food items, sweets, gifts, cosmetics, home decor
- Thanksgiving: Food items, cooking supplies, home goods
- Chinese New Year: Food, decorations, red envelopes, new clothes, gifts
- Holi: Colors, sweets, beverages, festive clothing
- Ramadan: Dates, food items, prayer items, clothing, gifts

⚠️ ACTION REQUIRED: In your response, you MUST:
1. Identify which products from the data are relevant to ${metadata.upcomingFestival}
2. Recommend INCREASED inventory levels for festival-relevant products
3. Provide specific percentage increases (e.g., "Increase by 40-60% for festival demand")
4. Warn about potential stockouts for festival-popular items
5. Suggest pre-festival ordering timelines`
    : '';

  const seasonContext = metadata.season
    ? `\n\n🌤️ Current Season (Auto-Detected): ${metadata.season}
The current season was automatically determined based on the date (${new Date().toLocaleDateString()}) and hemisphere of ${metadata.country}.

Factor in seasonal demand patterns:
- Weather-related product demand changes
- Seasonal clothing, food, and lifestyle needs
- ${metadata.season}-specific consumer behavior in ${metadata.location}
- Supply chain considerations for ${metadata.season} in ${metadata.country}
- Temperature and climate impact on product categories`
    : '';

  const hotspotContext = metadata.nearbyHotspot
    ? `\n\n📍 NEARBY HOTSPOT IMPACT: ${metadata.nearbyHotspot}

⚠️ CRITICAL: The business is located near a ${metadata.nearbyHotspot}. This significantly impacts demand patterns and customer demographics.

Consider the following hotspot-specific factors:

${getHotspotImpact(metadata.nearbyHotspot, metadata.category)}

🎯 HOTSPOT-DRIVEN ANALYSIS REQUIRED:
- Identify products with HIGH DEMAND due to ${metadata.nearbyHotspot} proximity
- Consider peak hours and traffic patterns specific to ${metadata.nearbyHotspot}
- Account for demographic profile of ${metadata.nearbyHotspot} visitors/users
- Adjust inventory recommendations based on foot traffic from ${metadata.nearbyHotspot}
- Consider seasonal variations in ${metadata.nearbyHotspot} activity
- Factor in special events or schedules related to ${metadata.nearbyHotspot}

Example: If near a University, expect higher demand for snacks, beverages, stationery during academic terms, with drops during holidays.`
    : '';

  return `You are an expert retail demand forecasting and inventory optimization assistant with deep knowledge of supply chain management, seasonal trends, geographic market dynamics, and category-specific consumer behavior.

# BUSINESS CONTEXT

Location: ${metadata.location}, ${metadata.state}, ${metadata.country}
Business Category: ${metadata.category}
Analysis Date: ${metadata.uploadDate ? new Date(metadata.uploadDate).toLocaleDateString() : 'Current'}
Data Period: Monthly sales data (MM-YYYY format)${festivalContext}${seasonContext}${hotspotContext}${populationContext}

# GEOGRAPHIC CONSIDERATIONS

Consider the following geographic factors in your analysis:
- Regional economic conditions in ${metadata.state}, ${metadata.country}
- Local market dynamics and consumer preferences in ${metadata.location}
- Seasonal patterns specific to this geographic region
- Cultural events, holidays, and festivals relevant to ${metadata.country}
- Climate and weather patterns affecting demand in this location
- Local competition and market saturation
- Regional supply chain constraints or advantages${metadata.upcomingFestival ? `\n- CRITICAL: Impact of upcoming ${metadata.upcomingFestival} on demand` : ''}${metadata.season ? `\n- ${metadata.season} season effects on product demand` : ''}${metadata.nearbyHotspot ? `\n- CRITICAL: Proximity to ${metadata.nearbyHotspot} affecting foot traffic and customer demographics` : ''}

# CATEGORY-SPECIFIC ANALYSIS

Business Type: ${metadata.category}

Apply category-specific expertise:
${getCategoryGuidelines(metadata.category)}

# SALES DATA ANALYSIS

Total Products Analyzed: ${salesData.summary.totalProducts}
Total Revenue: $${salesData.summary.totalRevenue.toFixed(2)}
Average Monthly Growth Rate: ${salesData.summary.avgGrowthRate.toFixed(2)}%
Total Current Inventory: ${salesData.summary.totalStocksLeft} units
High-Risk Products (stockout): ${salesData.summary.highRiskProducts}

## Detailed Product Performance

Product | Category | Avg Monthly Sales | Growth Rate | Current Stock | Months Until Stockout | Risk Level${columns.dynamic && columns.dynamic.length > 0 ? ' | Additional Attributes' : ''}
${productsTable}

⚠️ IMPORTANT: The sales figures above reflect historical demand during the data period. You MUST adjust these based on population changes for accurate current/future forecasting.
${dynamicColumnsDesc}

# ANALYSIS REQUIREMENTS

Perform a comprehensive analysis considering:

1. **Demand Forecasting (Next 3-6 Months)**
   - Analyze historical growth trends and volatility
   - ⚠️ CRITICAL: Calculate and apply population adjustment factor based on data years vs current year
   - Consider seasonal patterns for ${metadata.category} in ${metadata.country}${metadata.season ? ` during ${metadata.season}` : ''}
   - Factor in geographic market conditions and population dynamics${metadata.upcomingFestival ? `\n   - ⚠️ CRITICAL: Account for ${metadata.upcomingFestival} impact on demand (this is a major event!)` : ''}
   - Identify emerging trends and demand shifts
   - Account for category-specific demand drivers
   - Base all forecasts on current population levels, not historical data period population

2. **Inventory Risk Assessment**
   - Identify products at HIGH risk of stockout (< 2 months of inventory)
   - Calculate precise stockout timelines based on current stock and sales velocity
   - Identify overstock situations (slow-moving inventory)
   - Consider lead times for ${metadata.category} products

3. **Growth Opportunities**
   - Highlight products with strong positive growth momentum
   - Identify underperforming products with potential
   - Recommend products to promote or expand

4. **Geographic & Category Insights**
   - Provide insights specific to ${metadata.location}, ${metadata.state}
   - Consider local market conditions and consumer behavior
   - ⚠️ Account for population dynamics between data period and current year
   - Apply ${metadata.category}-specific best practices
   - Factor in regional supply chain considerations

5. **Actionable Recommendations**
   - Provide specific reorder quantities with priority levels
   - Suggest optimal reorder timing
   - Recommend inventory adjustments (increase/decrease/maintain)
   - Include contingency plans for high-risk items

# CRITICAL REQUIREMENTS

1. You MUST return AT LEAST 3-5 products in "topGrowingProducts" array
2. You MUST return AT LEAST 3-5 products in "stockoutRisk" array
3. You MUST return AT LEAST 3-5 products in "inventoryRecommendations" array
4. Each array should contain MULTIPLE items, not just one

# REQUIRED OUTPUT FORMAT

Return ONLY a valid JSON object (no markdown, no code blocks) with this exact structure:

{
  "demandOutlook": "Comprehensive 2-3 sentence outlook for the next 3-6 months, considering geography, category, and current trends. MUST mention ${metadata.location}, ${metadata.state}, ${metadata.country} and explicitly state the population adjustment factor applied${metadata.upcomingFestival ? ` and the impact of ${metadata.upcomingFestival}` : ''}${metadata.season ? ` during ${metadata.season} season` : ''}",
  "populationAnalysis": {
    "historicalPopulation": "Estimated population during data period (with year)",
    "currentPopulation": "Estimated current population (${new Date().getFullYear()})",
    "populationFactor": "Calculated adjustment factor (e.g., 1.15 for 15% growth)",
    "impact": "Brief explanation of how this population change affects demand forecasting"
  },
  "topGrowingProducts": [
    {
      "name": "Product name",
      "growth": "Growth percentage with trend",
      "reason": "Detailed explanation considering geography, seasonality, category factors, AND population-driven demand changes${metadata.upcomingFestival ? `. If this product is relevant to ${metadata.upcomingFestival}, EXPLICITLY mention the festival impact` : ''}",
      "recommendation": "Specific action to capitalize on growth. Include population-adjusted quantity recommendations${metadata.upcomingFestival ? `. For festival-relevant products, recommend aggressive inventory increase (e.g., 'Increase inventory by 50% for ${metadata.upcomingFestival} demand')` : ''}"
    },
    {
      "name": "Second product name",
      "growth": "Growth percentage",
      "reason": "Explanation${metadata.upcomingFestival ? ' with festival impact if relevant' : ''}",
      "recommendation": "Action${metadata.upcomingFestival ? ' with festival-specific inventory guidance' : ''}"
    },
    {
      "name": "Third product name",
      "growth": "Growth percentage",
      "reason": "Explanation${metadata.upcomingFestival ? ' with festival impact if relevant' : ''}",
      "recommendation": "Action${metadata.upcomingFestival ? ' with festival-specific inventory guidance' : ''}"
    }
  ],
  "stockoutRisk": [
    {
      "name": "Product name",
      "risk": "High/Medium/Low",
      "monthsUntilStockout": number,
      "currentStock": number,
      "monthlySalesRate": number,
      "action": "Specific reorder action with quantity and urgency",
      "contingencyPlan": "Backup plan if stockout occurs"
    },
    {
      "name": "Second product",
      "risk": "High/Medium/Low",
      "monthsUntilStockout": number,
      "currentStock": number,
      "monthlySalesRate": number,
      "action": "Action",
      "contingencyPlan": "Plan"
    },
    {
      "name": "Third product",
      "risk": "High/Medium/Low",
      "monthsUntilStockout": number,
      "currentStock": number,
      "monthlySalesRate": number,
      "action": "Action",
      "contingencyPlan": "Plan"
    }
  ],
  "overstockRisk": [
    {
      "name": "Product name",
      "risk": "High/Medium/Low",
      "excessUnits": number,
      "monthsOfInventory": number,
      "action": "Specific action to reduce overstock",
      "reason": "Why this product is overstocked"
    }
  ],
  "inventoryRecommendations": [
    {
      "product": "Product name",
      "action": "Increase order/Urgent restock/Maintain current/Reduce order",
      "quantity": number,
      "priority": "Critical/High/Normal/Low",
      "timing": "When to order",
      "reasoning": "Why this recommendation is made. MUST explain how population change affects this recommendation and include the population-adjusted quantity calculation${metadata.upcomingFestival ? `. If product is relevant to ${metadata.upcomingFestival}, MUST mention festival demand and recommend higher quantities` : ''}"
    },
    {
      "product": "Second product",
      "action": "Action type",
      "quantity": number,
      "priority": "Priority level",
      "timing": "Timing",
      "reasoning": "Reason${metadata.upcomingFestival ? ' with festival consideration' : ''}"
    },
    {
      "product": "Third product",
      "action": "Action type",
      "quantity": number,
      "priority": "Priority level",
      "timing": "Timing",
      "reasoning": "Reason${metadata.upcomingFestival ? ' with festival consideration' : ''}"
    }
  ],
  "geographicInsights": [
    "Insight specific to ${metadata.location}, ${metadata.state}, ${metadata.country}",
    "Regional market trend or opportunity",
    "Local consumer behavior pattern"
  ],
  "categoryInsights": [
    "Insight specific to ${metadata.category} business",
    "Category-specific trend or best practice",
    "Industry benchmark or comparison"
  ],
  "keyInsights": [
    "Critical business insight with actionable recommendation",
    "Important trend or pattern discovered",
    "Strategic opportunity or risk identified"
  ],
  "riskSummary": {
    "criticalActions": number,
    "highPriorityActions": number,
    "estimatedRevenueAtRisk": number,
    "opportunityValue": number
  }
}

IMPORTANT: 
- Return MULTIPLE products in each array (minimum 3-5 items)
- MUST mention the actual location (${metadata.location}, ${metadata.state}, ${metadata.country}) in demandOutlook${metadata.upcomingFestival ? `\n- CRITICAL: Identify and highlight products with HIGH DEMAND during ${metadata.upcomingFestival}` : ''}${metadata.upcomingFestival ? `\n- Festival-relevant products MUST have increased inventory recommendations (40-60% increase)` : ''}${metadata.upcomingFestival ? `\n- Explicitly mention ${metadata.upcomingFestival} impact in product recommendations` : ''}
- Return ONLY the JSON object, no markdown formatting, no code blocks
- Ensure all recommendations are specific to the provided location and category`;
};

function getCategoryGuidelines(category) {
  const guidelines = {
    'Grocery': `- Consider perishability and shelf life
- Factor in weekly shopping patterns and weekend spikes
- Account for seasonal produce availability
- Consider local dietary preferences and cultural food habits
- Monitor staple vs. premium product mix`,
    
    'Electronics': `- Account for product lifecycle and new model releases
- Consider warranty and return patterns
- Factor in technology adoption rates in the region
- Monitor price elasticity and promotional effectiveness
- Consider seasonal demand (back-to-school, holidays)`,
    
    'Cosmetics': `- Consider seasonal beauty trends and weather effects
- Factor in brand loyalty and premium vs. budget segments
- Account for influencer and social media impact
- Monitor expiration dates and product freshness
- Consider local beauty standards and preferences`,
    
    'Clothing': `- Account for seasonal fashion cycles
- Consider local climate and weather patterns
- Factor in cultural dress preferences and occasions
- Monitor size distribution and fit preferences
- Consider fast fashion vs. classic styles`,
    
    'Pharmacy': `- Consider seasonal illness patterns
- Factor in prescription vs. OTC product mix
- Account for chronic condition management needs
- Monitor expiration dates strictly
- Consider local health trends and concerns`,
    
    'Hardware': `- Consider project seasonality (spring/summer for outdoor)
- Factor in professional vs. DIY customer segments
- Account for bulk purchase patterns
- Monitor tool durability and replacement cycles
- Consider local construction and renovation trends`,
    
    'General': `- Analyze general retail patterns
- Consider seasonal shopping behaviors
- Factor in local economic conditions
- Monitor price sensitivity
- Consider competitive landscape`
  };
  
  return guidelines[category] || guidelines['General'];
}

// Helper function to extract years from sales data
function extractYearsFromData(salesData) {
  const years = new Set();
  
  // Try to extract years from product monthly sales data
  if (salesData.products && salesData.products.length > 0) {
    salesData.products.forEach(product => {
      if (product.monthlySales) {
        product.monthlySales.forEach(sale => {
          if (sale.date) {
            // Try to extract year from various date formats
            // MM-YYYY format
            const mmYyyyMatch = sale.date.match(/\d{2}-(\d{4})/);
            if (mmYyyyMatch) {
              years.add(mmYyyyMatch[1]);
              return;
            }
            
            // YYYY-MM-DD format
            const yyyyMmDdMatch = sale.date.match(/^(\d{4})-\d{2}-\d{2}/);
            if (yyyyMmDdMatch) {
              years.add(yyyyMmDdMatch[1]);
              return;
            }
            
            // Try to parse as date
            const dateObj = new Date(sale.date);
            if (!isNaN(dateObj.getTime())) {
              years.add(dateObj.getFullYear().toString());
            }
          }
        });
      }
    });
  }
  
  // Return sorted array of unique years
  return Array.from(years).sort();
}

// Helper function to provide hotspot-specific impact analysis
function getHotspotImpact(hotspot, category) {
  const impacts = {
    'University': `
**University/College Impact:**
- High foot traffic during academic terms (September-May typically)
- Student demographic: Budget-conscious, convenience-focused
- Peak hours: Morning (8-10 AM), Lunch (12-2 PM), Evening (4-7 PM)
- High demand: Snacks, beverages, stationery, affordable meals, personal care
- Seasonal drops: Summer break, winter holidays, exam periods (reduced social spending)
- Special events: Orientation week, graduation, sports events boost demand
- Category-specific: ${category === 'Grocery' ? 'Ready-to-eat, instant foods, energy drinks' : category === 'Electronics' ? 'Laptops, accessories, budget phones' : 'Budget-friendly products'}`,

    'Corporate Office': `
**Corporate Office/Business Park Impact:**
- Consistent weekday traffic (Monday-Friday)
- Professional demographic: Higher disposable income, quality-focused
- Peak hours: Morning (8-9 AM), Lunch (12-2 PM), Evening (5-7 PM)
- High demand: Quick meals, coffee, professional attire, convenience items
- Weekend drops: Significantly reduced traffic on weekends
- Special events: Corporate events, conferences increase demand
- Category-specific: ${category === 'Grocery' ? 'Premium snacks, healthy options, coffee' : category === 'Clothing' ? 'Formal wear, business casual' : 'Quality over quantity'}`,

    'Shopping Mall': `
**Shopping Mall Impact:**
- High weekend and evening traffic
- Diverse demographic: Families, young adults, tourists
- Peak hours: Weekends (11 AM-9 PM), Weekday evenings (5-9 PM)
- High demand: Impulse purchases, entertainment-related items, food
- Seasonal spikes: Holidays, festivals, sale seasons
- Special events: Mall events, movie releases, promotional days
- Category-specific: ${category === 'Grocery' ? 'Snacks, beverages, quick meals' : category === 'Electronics' ? 'Accessories, gadgets, entertainment' : 'Variety and novelty items'}`,

    'Market': `
**Traditional Market Impact:**
- Morning peak traffic (6-11 AM)
- Local demographic: Price-conscious, bulk buyers, regular customers
- Peak days: Weekends, market days, festival preparations
- High demand: Fresh produce, bulk items, daily essentials
- Cultural patterns: Festival shopping, weekly bulk purchases
- Special events: Festival seasons, harvest times
- Category-specific: ${category === 'Grocery' ? 'Fresh items, bulk staples, local preferences' : 'Traditional and essential items'}`,

    'Hospital': `
**Hospital/Medical Center Impact:**
- 24/7 consistent traffic with peak visiting hours
- Diverse demographic: Patients, visitors, medical staff
- Peak hours: Visiting hours (typically 10 AM-8 PM)
- High demand: Convenience items, comfort food, personal care, health products
- Emotional purchases: Gifts, flowers, comfort items
- Special needs: Quick service, hygiene products, nutritious options
- Category-specific: ${category === 'Pharmacy' ? 'High demand for OTC medicines, health supplements' : category === 'Grocery' ? 'Healthy snacks, beverages, comfort food' : 'Convenience and necessity items'}`,

    'Stadium': `
**Stadium/Sports Complex Impact:**
- Event-driven traffic (match days, events)
- Sports enthusiast demographic: Energetic, social, celebratory
- Peak hours: Before/during/after events (typically 2-4 hours per event)
- High demand: Snacks, beverages, sports merchandise, quick meals
- Seasonal patterns: Sports seasons, tournament schedules
- Special events: Major matches, championships, concerts
- Category-specific: ${category === 'Grocery' ? 'Beverages, snacks, party supplies' : category === 'Clothing' ? 'Sports apparel, team merchandise' : 'Event-related items'}`,

    'Park': `
**Park/Recreation Area Impact:**
- Weather-dependent traffic
- Family and fitness demographic: Health-conscious, leisure-focused
- Peak hours: Early morning (6-9 AM), Evening (4-7 PM), Weekends
- High demand: Healthy snacks, beverages, sports equipment, outdoor items
- Seasonal patterns: Higher traffic in pleasant weather, lower in extreme conditions
- Special events: Community events, festivals, sports activities
- Category-specific: ${category === 'Grocery' ? 'Healthy snacks, water, energy drinks' : 'Outdoor and recreational items'}`,

    'Tourist Attraction': `
**Tourist Attraction Impact:**
- Tourist demographic: Higher spending, souvenir-focused, convenience-seeking
- Peak hours: Daytime (10 AM-6 PM), varies by season
- High demand: Souvenirs, convenience items, local specialties, quick meals
- Seasonal patterns: Tourist seasons, holidays, vacation periods
- Cultural factors: International visitors, local tourism patterns
- Special events: Festivals, cultural events, peak tourist season
- Category-specific: ${category === 'Grocery' ? 'Packaged local specialties, beverages, snacks' : 'Souvenirs, local products, convenience items'}`,

    'Transportation Hub': `
**Transportation Hub (Station/Airport) Impact:**
- Continuous traffic with peak commute hours
- Transient demographic: Time-pressed, convenience-focused, diverse
- Peak hours: Morning rush (6-9 AM), Evening rush (5-8 PM)
- High demand: Grab-and-go items, travel essentials, convenience products
- Seasonal patterns: Holiday travel, vacation seasons
- Special needs: Quick service, portable items, travel-sized products
- Category-specific: ${category === 'Grocery' ? 'Ready-to-eat, beverages, snacks' : category === 'Pharmacy' ? 'Travel health items, personal care' : 'Convenience and portability'}`,

    'Residential Complex': `
**Large Residential Complex Impact:**
- Resident demographic: Families, working professionals, regular customers
- Peak hours: Morning (7-9 AM), Evening (6-9 PM), Weekends
- High demand: Daily essentials, groceries, household items
- Loyalty potential: Regular customers, subscription opportunities
- Seasonal patterns: Festival preparations, seasonal needs
- Special events: Community events, festivals, celebrations
- Category-specific: ${category === 'Grocery' ? 'Daily essentials, fresh produce, household items' : 'Regular use and family-oriented products'}`,

    'Industrial Area': `
**Industrial Area Impact:**
- Worker demographic: Blue-collar workers, shift-based traffic
- Peak hours: Shift changes (typically 6-8 AM, 2-4 PM, 10 PM-12 AM)
- High demand: Affordable meals, beverages, basic necessities
- Weekday focus: Reduced weekend traffic
- Special needs: Quick service, value for money, bulk options
- Category-specific: ${category === 'Grocery' ? 'Affordable meals, energy drinks, snacks' : 'Practical and value-oriented items'}`,

    'Tech Park': `
**Tech Park/IT Hub Impact:**
- Tech professional demographic: Higher income, convenience-focused, modern preferences
- Peak hours: Lunch (12-2 PM), Evening (6-8 PM), Late night (for night shifts)
- High demand: Premium snacks, coffee, health foods, tech accessories
- Weekday focus: Monday-Friday traffic, some weekend work
- Special needs: Quality products, healthy options, quick service
- Category-specific: ${category === 'Grocery' ? 'Premium snacks, health foods, specialty coffee' : category === 'Electronics' ? 'Accessories, gadgets, tech supplies' : 'Quality and convenience'}`
  };

  return impacts[hotspot] || `
**${hotspot} Impact:**
- Consider the specific demographic and traffic patterns of ${hotspot}
- Analyze peak hours and seasonal variations
- Adjust inventory based on customer behavior near ${hotspot}
- Factor in special events and activities related to ${hotspot}`;
}

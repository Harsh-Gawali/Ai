# AI-Powered Consumer Goods Inventory Demand Forecast System

A production-grade, visually stunning inventory forecasting system that uses AI to analyze sales data and generate intelligent demand predictions and inventory recommendations.

## Features

- **AI-Powered Forecasting**: LLM integration for natural language insights
- **Beautiful UI**: Glassmorphism design with smooth animations
- **Real-time Analytics**: Interactive charts and visualizations
- **CSV Upload**: Easy data import with drag-and-drop
- **Synthetic Data**: Built-in sample data generator
- **Demand Predictions**: 30-day forecast with confidence scores
- **Risk Analysis**: Stockout and overstock alerts
- **Inventory Recommendations**: AI-driven ordering suggestions

## Tech Stack

### Frontend
- React 18 with Vite
- TailwindCSS for styling
- Framer Motion for animations
- Recharts for data visualization
- React Dropzone for file uploads
- Lucide React for icons

### Backend
- Node.js with Express
- Multer for file handling
- CSV Parser for data processing
- Axios for API calls
- LLM API integration (OpenAI/Anthropic compatible)

## Installation

### Prerequisites
- Node.js 18+ installed
- npm or yarn package manager

### Setup

1. Clone the repository
```bash
git clone <repository-url>
cd inventory-forecast-system
```

2. Install backend dependencies
```bash
npm install
```

3. Install frontend dependencies
```bash
cd client
npm install
cd ..
```

4. Configure environment variables
```bash
# Edit .env file
LLM_API_KEY=your_tcs_genai_api_key
LLM_BASE_URL=https://genailab.tcs.in
LLM_MODEL=azure_ai/genailab-maas-DeepSeek-V3-0324
PORT=5000
```

Available Models:
- azure/genailab-maas-gpt-35-turbo
- azure/genailab-maas-gpt-4o
- azure/genailab-maas-gpt-4o-mini
- azure_ai/genailab-maas-DeepSeek-R1
- azure_ai/genailab-maas-DeepSeek-V3-0324 (default)
- azure_ai/genailab-maas-Llama-3.3-70B-Instruct
- azure_ai/genailab-maas-Phi-4-reasoning

5. Start the application

**Terminal 1 - Backend:**
```bash
npm start
```
Backend runs on http://localhost:5000

**Terminal 2 - Frontend:**
```bash
cd client
npm start
```
Frontend runs on http://localhost:3000

## Usage

### Upload Sales Data

1. Navigate to the Upload page
2. Drag and drop a CSV file or click to browse
3. Alternatively, click "Load Sample Data" to use synthetic data

### CSV Format

Your CSV file should have the following columns:
```csv
date,product_name,category,units_sold,price
2024-09-01,Shampoo,Personal Care,45,6.99
```

### View Forecast

After uploading data, you'll be redirected to the Forecast page showing:
- AI-generated demand outlook
- Top growing products
- Stockout risk alerts
- Overstock warnings
- Inventory ordering recommendations
- Interactive charts and visualizations

## API Endpoints

### POST /api/upload-sales-data
Upload CSV file for analysis
- Body: multipart/form-data with 'file' field
- Returns: Analyzed sales data

### POST /api/generate-forecast
Generate AI forecast from sales data
- Body: `{ salesData: {...} }`
- Returns: Forecast with recommendations

### GET /api/sample-data
Get synthetic sales data
- Returns: 180 days of generated sales data

## Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── App.jsx        # Main app component
│   │   └── main.jsx       # Entry point
│   └── package.json
├── server/                # Express backend
│   ├── controllers/       # Request handlers
│   ├── routes/           # API routes
│   ├── services/         # Business logic
│   └── utils/            # Helper functions
├── sample-data.csv       # Example CSV file
└── package.json          # Root package file
```

## LLM Integration

The system supports any OpenAI-compatible LLM API. To integrate:

1. Add your API key to `.env`
2. Update `server/services/llmService.js` with your API endpoint
3. Adjust the prompt in `server/utils/promptBuilder.js` as needed

Currently uses mock data if no API key is provided.

## Features Breakdown

### Data Analysis
- Aggregates sales by product
- Calculates average daily sales
- Computes growth rates and volatility
- Identifies trends and patterns

### AI Forecast
- Demand outlook for next 30 days
- Product growth predictions
- Stockout risk assessment
- Overstock identification
- Inventory recommendations
- Retail insights

### Visualizations
- Revenue ranking bar chart
- Category distribution pie chart
- Sales trend line charts
- Product demand heatmaps

## Customization

### Styling
- Edit `client/tailwind.config.js` for theme customization
- Modify `client/src/index.css` for global styles
- Adjust glassmorphism effects in component classes

### Data Processing
- Customize analysis logic in `server/services/dataAnalyzer.js`
- Modify synthetic data in `server/services/dataGenerator.js`
- Adjust forecast prompts in `server/utils/promptBuilder.js`

## Production Deployment

### Build Frontend
```bash
cd client
npm run build
```

### Deploy Backend
```bash
# Set environment variables
export LLM_API_KEY=your_key
export NODE_ENV=production

# Start server
npm run server
```

### Serve Static Files
Configure Express to serve the built frontend from `client/dist`

## License

MIT

## Support

For issues or questions, please open an issue on GitHub.

import fs from 'fs';

// Grocery products
const groceryProducts = [
  { name: 'Shampoo', category: 'Personal Care', basePrice: 6.99, baseUnits: 450, baseStock: 1200, brand: 'BrandA', organic: 'No' },
  { name: 'Soap', category: 'Personal Care', basePrice: 2.50, baseUnits: 600, baseStock: 800, brand: 'BrandB', organic: 'Yes' },
  { name: 'Toothpaste', category: 'Oral Care', basePrice: 4.20, baseUnits: 300, baseStock: 500, brand: 'BrandC', organic: 'No' },
  { name: 'Rice', category: 'Food', basePrice: 12.99, baseUnits: 250, baseStock: 300, brand: 'BrandD', organic: 'Yes' },
  { name: 'Milk', category: 'Dairy', basePrice: 3.99, baseUnits: 800, baseStock: 150, brand: 'BrandE', organic: 'Yes' },
  { name: 'Chips', category: 'Snacks', basePrice: 3.49, baseUnits: 550, baseStock: 900, brand: 'BrandF', organic: 'No' },
  { name: 'Soft Drinks', category: 'Beverages', basePrice: 1.99, baseUnits: 1000, baseStock: 2000, brand: 'BrandG', organic: 'No' },
  { name: 'Detergent', category: 'Household', basePrice: 8.99, baseUnits: 350, baseStock: 600, brand: 'BrandH', organic: 'No' }
];

// Electronics products
const electronicsProducts = [
  { name: 'Smartphone X1', category: 'Mobile', basePrice: 599.99, baseUnits: 45, baseStock: 80, warranty: 24, screen: '6.5' },
  { name: 'Laptop Pro', category: 'Computers', basePrice: 1299.99, baseUnits: 25, baseStock: 30, warranty: 36, screen: '15.6' },
  { name: 'Wireless Earbuds', category: 'Audio', basePrice: 89.99, baseUnits: 120, baseStock: 200, warranty: 12, screen: '' },
  { name: 'Smart TV 55', category: 'Television', basePrice: 799.99, baseUnits: 35, baseStock: 40, warranty: 24, screen: '55' },
  { name: 'Tablet Air', category: 'Tablets', basePrice: 449.99, baseUnits: 50, baseStock: 60, warranty: 24, screen: '10.5' },
  { name: 'Gaming Console', category: 'Gaming', basePrice: 499.99, baseUnits: 40, baseStock: 25, warranty: 12, screen: '' },
  { name: 'Smartwatch Pro', category: 'Wearables', basePrice: 299.99, baseUnits: 80, baseStock: 150, warranty: 24, screen: '1.9' },
  { name: 'Bluetooth Speaker', category: 'Audio', basePrice: 59.99, baseUnits: 95, baseStock: 180, warranty: 12, screen: '' }
];

// Generate months from Jan 2015 to Mar 2026
const months = [];
for (let year = 2015; year <= 2026; year++) {
  const lastMonth = year === 2026 ? 3 : 12;
  for (let month = 1; month <= lastMonth; month++) {
    months.push(`${String(month).padStart(2, '0')}-${year}`);
  }
}

console.log(`Generating ${months.length} months of data from ${months[0]} to ${months[months.length - 1]}`);

// Generate grocery data
let groceryCSV = 'month,product_name,category,units_sold,price,stocks_left,brand,organic\n';
months.forEach((month, monthIndex) => {
  groceryProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 0.8;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.2;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.15;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(1.025, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    groceryCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.brand},${product.organic}\n`;
  });
});

fs.writeFileSync('sample-data-grocery.csv', groceryCSV);
console.log(`✅ Generated sample-data-grocery.csv with ${months.length * groceryProducts.length} records`);

// Generate electronics data
let electronicsCSV = 'month,product_name,category,units_sold,price,stocks_left,warranty_months,screen_size\n';
months.forEach((month, monthIndex) => {
  electronicsProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 1.2;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.25;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.2;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(0.98, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    electronicsCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.warranty},${product.screen}\n`;
  });
});

fs.writeFileSync('sample-data-electronics.csv', electronicsCSV);
console.log(`✅ Generated sample-data-electronics.csv with ${months.length * electronicsProducts.length} records`);

// Cosmetics products
const cosmeticsProducts = [
  { name: 'Foundation', category: 'Face Makeup', basePrice: 24.99, baseUnits: 180, baseStock: 350, brand: 'GlamCo', spf: '15' },
  { name: 'Lipstick', category: 'Lip Makeup', basePrice: 12.99, baseUnits: 320, baseStock: 600, brand: 'ColorPro', spf: '' },
  { name: 'Mascara', category: 'Eye Makeup', basePrice: 15.99, baseUnits: 250, baseStock: 450, brand: 'LashMax', spf: '' },
  { name: 'Face Cream', category: 'Skincare', basePrice: 34.99, baseUnits: 200, baseStock: 400, brand: 'DermaCare', spf: '30' },
  { name: 'Perfume', category: 'Fragrance', basePrice: 59.99, baseUnits: 90, baseStock: 180, brand: 'Essence', spf: '' },
  { name: 'Nail Polish', category: 'Nail Care', basePrice: 8.99, baseUnits: 280, baseStock: 550, brand: 'NailArt', spf: '' },
  { name: 'Eye Shadow Palette', category: 'Eye Makeup', basePrice: 29.99, baseUnits: 140, baseStock: 280, brand: 'ColorPro', spf: '' },
  { name: 'Serum', category: 'Skincare', basePrice: 44.99, baseUnits: 160, baseStock: 320, brand: 'DermaCare', spf: '' }
];

// Clothing & Fashion products
const clothingProducts = [
  { name: 'T-Shirt', category: 'Casual Wear', basePrice: 19.99, baseUnits: 450, baseStock: 800, brand: 'UrbanStyle', size: 'M' },
  { name: 'Jeans', category: 'Bottoms', basePrice: 49.99, baseUnits: 280, baseStock: 500, brand: 'DenimCo', size: '32' },
  { name: 'Dress', category: 'Formal Wear', basePrice: 79.99, baseUnits: 180, baseStock: 350, brand: 'Elegance', size: 'M' },
  { name: 'Sneakers', category: 'Footwear', basePrice: 69.99, baseUnits: 220, baseStock: 400, brand: 'SportFit', size: '9' },
  { name: 'Jacket', category: 'Outerwear', basePrice: 89.99, baseUnits: 150, baseStock: 280, brand: 'UrbanStyle', size: 'L' },
  { name: 'Handbag', category: 'Accessories', basePrice: 59.99, baseUnits: 190, baseStock: 320, brand: 'LuxBag', size: '' },
  { name: 'Scarf', category: 'Accessories', basePrice: 24.99, baseUnits: 260, baseStock: 450, brand: 'Elegance', size: '' },
  { name: 'Socks', category: 'Basics', basePrice: 9.99, baseUnits: 600, baseStock: 1000, brand: 'ComfortWear', size: 'L' }
];

// General Retail products
const generalRetailProducts = [
  { name: 'Notebook', category: 'Stationery', basePrice: 4.99, baseUnits: 380, baseStock: 650, brand: 'PaperPro', pages: '200' },
  { name: 'Pen Set', category: 'Stationery', basePrice: 7.99, baseUnits: 420, baseStock: 700, brand: 'WriteWell', pages: '' },
  { name: 'Water Bottle', category: 'Home Goods', basePrice: 14.99, baseUnits: 290, baseStock: 500, brand: 'HydroLife', pages: '' },
  { name: 'Backpack', category: 'Bags', basePrice: 39.99, baseUnits: 180, baseStock: 320, brand: 'TravelPro', pages: '' },
  { name: 'Candles', category: 'Home Decor', basePrice: 12.99, baseUnits: 240, baseStock: 450, brand: 'AromaHome', pages: '' },
  { name: 'Phone Case', category: 'Electronics Accessories', basePrice: 19.99, baseUnits: 350, baseStock: 600, brand: 'TechGuard', pages: '' },
  { name: 'Sunglasses', category: 'Accessories', basePrice: 29.99, baseUnits: 210, baseStock: 380, brand: 'SunShield', pages: '' },
  { name: 'Umbrella', category: 'Accessories', basePrice: 16.99, baseUnits: 190, baseStock: 350, brand: 'RainGuard', pages: '' }
];

// Pharmacy products
const pharmacyProducts = [
  { name: 'Pain Relief', category: 'OTC Medicine', basePrice: 8.99, baseUnits: 420, baseStock: 700, brand: 'HealthPlus', prescription: 'No' },
  { name: 'Vitamins', category: 'Supplements', basePrice: 19.99, baseUnits: 350, baseStock: 600, brand: 'VitaLife', prescription: 'No' },
  { name: 'Cough Syrup', category: 'OTC Medicine', basePrice: 11.99, baseUnits: 280, baseStock: 500, brand: 'HealthPlus', prescription: 'No' },
  { name: 'Bandages', category: 'First Aid', basePrice: 6.99, baseUnits: 380, baseStock: 650, brand: 'MediCare', prescription: 'No' },
  { name: 'Antibiotic Cream', category: 'First Aid', basePrice: 9.99, baseUnits: 320, baseStock: 550, brand: 'MediCare', prescription: 'No' },
  { name: 'Allergy Medicine', category: 'OTC Medicine', basePrice: 14.99, baseUnits: 290, baseStock: 500, brand: 'HealthPlus', prescription: 'No' },
  { name: 'Thermometer', category: 'Medical Devices', basePrice: 24.99, baseUnits: 150, baseStock: 280, brand: 'TempCheck', prescription: 'No' },
  { name: 'Blood Pressure Monitor', category: 'Medical Devices', basePrice: 49.99, baseUnits: 90, baseStock: 180, brand: 'HealthTrack', prescription: 'No' }
];

// Hardware Store products
const hardwareProducts = [
  { name: 'Hammer', category: 'Hand Tools', basePrice: 19.99, baseUnits: 180, baseStock: 350, brand: 'ToolMaster', warranty: '12' },
  { name: 'Drill Set', category: 'Power Tools', basePrice: 89.99, baseUnits: 110, baseStock: 200, brand: 'PowerPro', warranty: '24' },
  { name: 'Paint Gallon', category: 'Paint & Supplies', basePrice: 34.99, baseUnits: 220, baseStock: 400, brand: 'ColorWorks', warranty: '' },
  { name: 'Screwdriver Set', category: 'Hand Tools', basePrice: 24.99, baseUnits: 240, baseStock: 450, brand: 'ToolMaster', warranty: '12' },
  { name: 'Light Bulbs', category: 'Electrical', basePrice: 12.99, baseUnits: 380, baseStock: 700, brand: 'BrightLife', warranty: '6' },
  { name: 'Extension Cord', category: 'Electrical', basePrice: 16.99, baseUnits: 290, baseStock: 500, brand: 'PowerLine', warranty: '12' },
  { name: 'Nails Box', category: 'Fasteners', basePrice: 8.99, baseUnits: 350, baseStock: 650, brand: 'BuildRight', warranty: '' },
  { name: 'Tape Measure', category: 'Measuring Tools', basePrice: 14.99, baseUnits: 260, baseStock: 480, brand: 'ToolMaster', warranty: '12' }
];

// Generate cosmetics data
let cosmeticsCSV = 'month,product_name,category,units_sold,price,stocks_left,brand,spf\n';
months.forEach((month, monthIndex) => {
  cosmeticsProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 0.9;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.22;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.18;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(1.028, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    cosmeticsCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.brand},${product.spf}\n`;
  });
});

fs.writeFileSync('sample-data-cosmetics.csv', cosmeticsCSV);
console.log(`✅ Generated sample-data-cosmetics.csv with ${months.length * cosmeticsProducts.length} records`);

// Generate clothing data
let clothingCSV = 'month,product_name,category,units_sold,price,stocks_left,brand,size\n';
months.forEach((month, monthIndex) => {
  clothingProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 0.85;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.28;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.2;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(1.022, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    clothingCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.brand},${product.size}\n`;
  });
});

fs.writeFileSync('sample-data-clothing.csv', clothingCSV);
console.log(`✅ Generated sample-data-clothing.csv with ${months.length * clothingProducts.length} records`);

// Generate general retail data
let generalRetailCSV = 'month,product_name,category,units_sold,price,stocks_left,brand,pages\n';
months.forEach((month, monthIndex) => {
  generalRetailProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 0.75;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.2;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.16;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(1.024, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    generalRetailCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.brand},${product.pages}\n`;
  });
});

fs.writeFileSync('sample-data-general-retail.csv', generalRetailCSV);
console.log(`✅ Generated sample-data-general-retail.csv with ${months.length * generalRetailProducts.length} records`);

// Generate pharmacy data
let pharmacyCSV = 'month,product_name,category,units_sold,price,stocks_left,brand,prescription\n';
months.forEach((month, monthIndex) => {
  pharmacyProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 0.95;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.25;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.14;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(1.03, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    pharmacyCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.brand},${product.prescription}\n`;
  });
});

fs.writeFileSync('sample-data-pharmacy.csv', pharmacyCSV);
console.log(`✅ Generated sample-data-pharmacy.csv with ${months.length * pharmacyProducts.length} records`);

// Generate hardware store data
let hardwareCSV = 'month,product_name,category,units_sold,price,stocks_left,brand,warranty\n';
months.forEach((month, monthIndex) => {
  hardwareProducts.forEach(product => {
    const longTermTrend = 1 + (monthIndex / months.length) * 0.7;
    const seasonality = 1 + Math.sin((monthIndex % 12) / 12 * Math.PI * 2) * 0.24;
    const randomness = 0.85 + Math.random() * 0.3;
    const economicCycle = 1 + Math.sin(monthIndex / 24) * 0.17;
    
    const units = Math.round(product.baseUnits * longTermTrend * seasonality * randomness * economicCycle);
    const yearsPassed = monthIndex / 12;
    const priceInflation = Math.pow(1.026, yearsPassed);
    const price = (product.basePrice * priceInflation * (0.95 + Math.random() * 0.1)).toFixed(2);
    const stockDecayFactor = Math.max(0.3, 1 - (monthIndex / months.length) * 0.7);
    const stocksLeft = Math.max(0, Math.round(product.baseStock * stockDecayFactor * (0.8 + Math.random() * 0.4)));
    
    hardwareCSV += `${month},${product.name},${product.category},${units},${price},${stocksLeft},${product.brand},${product.warranty}\n`;
  });
});

fs.writeFileSync('sample-data-hardware.csv', hardwareCSV);
console.log(`✅ Generated sample-data-hardware.csv with ${months.length * hardwareProducts.length} records`);

console.log('\n🎉 Sample data generation complete!');
